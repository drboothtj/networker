'''Create and analyse protein networks and subnetworks'''
